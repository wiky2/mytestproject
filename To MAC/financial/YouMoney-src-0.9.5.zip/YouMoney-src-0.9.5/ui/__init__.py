# coding: utf-8
import config, i18n
