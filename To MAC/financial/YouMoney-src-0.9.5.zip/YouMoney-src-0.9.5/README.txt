YouMoney是一个开源个人记账软件

感谢：
Jacky MA <jackyma1981@gmail.com> 制作了YouMoney的日文支持

安装方法：

Windows：可以选择YouMoney-x.x.x.exe的安装文件直接运行就安装。也可以用YouMoney-noinstall-x.x.x.exe直接解压缩就可以使用。
Linux: 可以用rpm，deb包来安装。下载对应的版本就可以。也可以从源码运行。需要保证python版本在2.5以上，但不能为3。wxPython版本在2.8.9以上。
MacOS X：下载dmg包，把里面的youmoney.app拖到桌面或者应用程序里即可。

